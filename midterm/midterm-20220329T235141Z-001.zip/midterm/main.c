#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int b;
int c;
int d;
int e;
int f;
int g;
int h;
int i;
int j;
int k;
int l;

int get_rolls() {
	int num;
	printf("Input the number of times to roll the pair of dice: ");
	scanf("%d", &num);
	return num;
}

int roll_die() {
	int num = rand();
	int dieNum = (rand() % 6) + 1;
	return dieNum;
}

void update_count(int diceSum) {
	if(diceSum == 2) {
		b++;
	}
	if(diceSum == 3) {
		c++;
	}
	if(diceSum == 4) {
		d++;
	}
	if(diceSum == 5) {
		e++;
	}
	if(diceSum == 6) {
		f++;
	}
	if(diceSum == 7) {
		g++;
	}
	if(diceSum == 8) {
		h++;
	}
	if(diceSum == 9) {
		i++;
	}
	if(diceSum == 10) {
		j++;
	}
	if(diceSum == 11) {
		k++;
	}
	if(diceSum == 12) {
		l++;
	}
}

void print_table() {
	printf("Sum of dice     Number of Occurences\n");
	printf("    02                 %d           \n", b);
	printf("    03                 %d           \n", c);
	printf("    04                 %d           \n", d);
	printf("    05                 %d           \n", e);
	printf("    06                 %d           \n", f);
	printf("    07                 %d           \n", g);
	printf("    08                 %d           \n", h);		
	printf("    09                 %d           \n", i);		
	printf("    10                 %d           \n", j);		
	printf("    11                 %d           \n", k);		
	printf("    12                 %d           \n", l);		
}
int main() {
	srand(time(0));
	int diceRolls = get_rolls();
	for (int i = 0; i < diceRolls; i++) {
		int dieOne = roll_die();
		int dieTwo = roll_die();
		int diceSum = dieOne + dieTwo;
		update_count(diceSum);
	}
	print_table();
	return 0;	
}

